// MindMetrics quiz logic
"use strict";

const BANK = [
  { c: "Technology", t: ["technology"], l: "easy", q: "A device stores 4 files. Each file is copied once. How many files are there now?", o: ["4", "6", "8", "12"], a: 2, e: "Each of the 4 files has one additional copy, so 4 × 2 = 8 files." },
  { c: "Technology", t: ["technology"], l: "medium", q: "A sequence follows this rule: 3, 6, 12, 24, __. What comes next?", o: ["30", "36", "48", "54"], a: 2, e: "Each number is doubled: 24 × 2 = 48." },
  { c: "Science", t: ["science"], l: "easy", q: "Which is the best example of a fair test?", o: ["Change several things at once", "Change one factor and keep others the same", "Use no measurements", "Choose the result first"], a: 1, e: "Changing one factor while controlling other conditions helps isolate its effect." },
  { c: "Science", t: ["science"], l: "medium", q: "A plant grows 2 cm each week. If it is 5 cm tall now, how tall will it be in 3 weeks?", o: ["8 cm", "10 cm", "11 cm", "15 cm"], a: 2, e: "It grows 2 × 3 = 6 cm, and 5 + 6 = 11 cm." },
  { c: "Nature", t: ["nature"], l: "easy", q: "Which living thing is a producer in a food chain?", o: ["Grass", "Rabbit", "Fox", "Eagle"], a: 0, e: "Plants such as grass make their own food using sunlight." },
  { c: "Nature", t: ["nature"], l: "medium", q: "If all insects in a meadow disappeared, which change is most likely?", o: ["Every plant immediately dies", "Some insect-eating animals lose a food source", "The Sun becomes dimmer", "Rocks stop weathering"], a: 1, e: "Many birds, amphibians, and other animals depend on insects for food." },
  { c: "Sports", t: ["sports"], l: "easy", q: "A team scores 3 points in each of 4 rounds. How many points did it score?", o: ["7", "10", "12", "16"], a: 2, e: "Four rounds of 3 points gives 3 × 4 = 12." },
  { c: "Sports", t: ["sports"], l: "medium", q: "A runner completes 2 km in 10 minutes at a steady pace. How long would 6 km take?", o: ["15 minutes", "20 minutes", "30 minutes", "60 minutes"], a: 2, e: "Six kilometres is three times the distance, so it takes 3 × 10 = 30 minutes." },
  { c: "Arts", t: ["arts"], l: "easy", q: "Which shape has exactly three sides?", o: ["Circle", "Triangle", "Rectangle", "Pentagon"], a: 1, e: "A triangle has three sides and three corners." },
  { c: "Arts", t: ["arts"], l: "medium", q: "A pattern repeats: circle, square, triangle, circle, square, __. What comes next?", o: ["Circle", "Square", "Triangle", "Rectangle"], a: 2, e: "The three-shape sequence repeats, so triangle follows circle and square." },
  { c: "Everyday Logic", t: ["everyday"], l: "easy", q: "You have 5 apples and give 2 away. How many apples remain?", o: ["2", "3", "5", "7"], a: 1, e: "Five minus two equals three." },
  { c: "Everyday Logic", t: ["everyday"], l: "medium", q: "All blue boxes are heavy. This box is blue. What must be true?", o: ["The box is heavy", "All heavy boxes are blue", "The box is empty", "No blue box is empty"], a: 0, e: "Every blue box is heavy, so this blue box is heavy." },
  { c: "Logic", t: ["everyday", "technology"], l: "easy", q: "Which number does not belong with the others?", o: ["2", "4", "7", "8"], a: 2, e: "Seven is odd; the other numbers are even." },
  { c: "Logic", t: ["everyday", "science"], l: "medium", q: "Mira is older than Sam. Sam is older than Lee. Who is youngest?", o: ["Mira", "Sam", "Lee", "Cannot tell"], a: 2, e: "From oldest to youngest: Mira, Sam, then Lee." },
  { c: "Technology", t: ["technology"], l: "medium", q: "If A = 1, B = 2, C = 3, what is the total value of CAB?", o: ["5", "6", "7", "8"], a: 1, e: "C + A + B = 3 + 1 + 2 = 6." },
  { c: "Science", t: ["science"], l: "easy", q: "Pure water freezes at approximately what temperature on the Celsius scale?", o: ["0°C", "10°C", "50°C", "100°C"], a: 0, e: "Pure water freezes at 0°C under standard atmospheric pressure." },
  { c: "Everyday Logic", t: ["everyday"], l: "medium", q: "A clock shows 3:00. What is the smaller angle between its hands?", o: ["45°", "60°", "90°", "180°"], a: 2, e: "At 3:00, the hands are a quarter turn apart: 90°." },
  { c: "Nature", t: ["nature", "science"], l: "medium", q: "Which adaptation would help a plant survive in a dry region?", o: ["Large thin leaves that lose lots of water", "Storing water in thick tissues", "Growing only underwater", "Having no roots"], a: 1, e: "Water-storing tissues can help plants survive dry periods." },
  { c: "Sports", t: ["sports", "everyday"], l: "medium", q: "A player wins 3 of 5 matches. What fraction did they win?", o: ["1/5", "2/5", "3/5", "5/3"], a: 2, e: "Three wins out of five matches is 3/5." },
  { c: "Arts", t: ["arts", "everyday"], l: "easy", q: "Which word is closest in meaning to 'brief'?", o: ["Short", "Noisy", "Bright", "Heavy"], a: 0, e: "'Brief' means short in duration or length." },
  { c: "Logic", t: ["everyday", "technology"], l: "medium", q: "Find the missing number: 1, 4, 9, 16, __.", o: ["20", "24", "25", "36"], a: 2, e: "These are square numbers, so the next is 5² = 25." },
  { c: "Science", t: ["science"], l: "medium", q: "A recipe for 2 people needs 150 g of flour. How much is needed for 4 people?", o: ["200 g", "250 g", "300 g", "600 g"], a: 2, e: "Four people is twice as many, so double 150 g to get 300 g." },
  { c: "Everyday Logic", t: ["everyday"], l: "easy", q: "If today is Tuesday, what day will it be in 3 days?", o: ["Wednesday", "Thursday", "Friday", "Saturday"], a: 2, e: "Three days after Tuesday is Friday." },
  { c: "Technology", t: ["technology", "science"], l: "medium", q: "A download is 50% complete. Another 25% of the whole file downloads. How complete is it?", o: ["55%", "65%", "75%", "100%"], a: 2, e: "50% + 25% = 75% of the full file." },
  { c: "Logic", t: ["everyday", "arts"], l: "medium", q: "Find the next letter: Z, X, V, T, __.", o: ["S", "R", "Q", "P"], a: 1, e: "The sequence moves backward by two letters: Z, X, V, T, R." },
  { c: "Nature", t: ["nature"], l: "easy", q: "Which process helps water vapour form clouds?", o: ["Condensation", "Combustion", "Magnetism", "Digestion"], a: 0, e: "Condensation turns water vapour into tiny liquid droplets." },
  { c: "Sports", t: ["sports"], l: "easy", q: "A match starts at 2:15 pm and lasts 45 minutes. When does it end?", o: ["2:45 pm", "3:00 pm", "3:15 pm", "3:30 pm"], a: 1, e: "Forty-five minutes after 2:15 pm is 3:00 pm." },
  { c: "Arts", t: ["arts"], l: "medium", q: "A design uses 2 red tiles for every 3 blue tiles. With 10 red tiles, how many blue tiles keep the ratio?", o: ["12", "15", "18", "20"], a: 1, e: "Multiply the ratio 2:3 by 5 to get 10:15." },
  { c: "Logic", t: ["everyday", "science"], l: "medium", q: "All tulips are flowers. Some flowers are yellow. Which statement must be true?", o: ["All tulips are yellow", "Some tulips are yellow", "Every tulip is a flower", "No flowers are tulips"], a: 2, e: "The first statement directly establishes that every tulip is a flower." },
  { c: "Everyday Logic", t: ["everyday"], l: "easy", q: "A bag contains 3 green and 2 yellow counters. How many counters are there altogether?", o: ["1", "5", "6", "8"], a: 1, e: "Three plus two equals five counters." }
];

const TOTAL = 20;
const DURATION = 15 * 60;
const LETTERS = ["A", "B", "C", "D"];
const $ = (selector) => document.querySelector(selector);

let profile;
let questions = [];
let answers = [];
let index = 0;
let secondsLeft = DURATION;
let timerId = null;
let startedAt = 0;
let finished = false;

function shuffle(items) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function makeQuestionSet(interests, difficulty) {
  let pool = BANK.filter((item) => item.t.some((tag) => interests.includes(tag)));
  if (difficulty !== "mixed") {
    const levelPool = pool.filter((item) => item.l === difficulty);
    if (levelPool.length >= TOTAL) pool = levelPool;
  }
  const selected = shuffle(pool).slice(0, TOTAL);
  if (selected.length < TOTAL) {
    selected.push(...shuffle(BANK.filter((item) => !selected.includes(item))).slice(0, TOTAL - selected.length));
  }
  return selected;
}

function startQuiz(event) {
  event.preventDefault();
  const data = new FormData($("#profile-form"));
  const interests = data.getAll("interest");
  const name = String(data.get("name") || "").trim();
  if (!interests.length || !name) {
    $("#form-error").textContent = !name ? "Please enter your name." : "Choose at least one interest.";
    $("#form-error").hidden = false;
    return;
  }
  $("#form-error").hidden = true;
  profile = { name, ageGroup: data.get("ageGroup"), difficulty: data.get("difficulty") };
  questions = makeQuestionSet(interests, profile.difficulty);
  answers = Array(questions.length).fill(null);
  index = 0;
  secondsLeft = DURATION;
  finished = false;
  startedAt = Date.now();
  $("#intro-screen").hidden = true;
  $("#results-screen").hidden = true;
  $("#quiz-screen").hidden = false;
  $("#welcome-label").textContent = `${name.toUpperCase()}'S QUIZ`;
  renderQuestion();
  updateTimer();
  clearInterval(timerId);
  timerId = setInterval(() => {
    secondsLeft -= 1;
    updateTimer();
    if (secondsLeft <= 0) finishQuiz(true);
  }, 1000);
}

function renderQuestion() {
  const item = questions[index];
  $("#question-category").textContent = item.c;
  $("#question-title").textContent = item.q;
  $("#question-counter").textContent = `Question ${index + 1} of ${questions.length}`;
  $("#answered-counter").textContent = `${answers.filter((answer) => answer !== null).length} answered`;
  $("#progress-fill").style.width = `${((index + 1) / questions.length) * 100}%`;
  $("#progress-track").setAttribute("aria-valuenow", String(index + 1));
  const container = $("#answer-options");
  container.replaceChildren();

  item.o.forEach((option, optionIndex) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-option";
    button.classList.toggle("selected", answers[index] === optionIndex);
    button.setAttribute("aria-pressed", String(answers[index] === optionIndex));
    const letter = document.createElement("span");
    letter.className = "option-letter";
    letter.textContent = LETTERS[optionIndex];
    const text = document.createElement("span");
    text.textContent = option;
    button.append(letter, text);
    button.addEventListener("click", () => {
      answers[index] = optionIndex;
      renderQuestion();
    });
    container.append(button);
  });

  $("#previous-button").disabled = index === 0;
  $("#previous-button").style.opacity = index === 0 ? ".5" : "1";
  $("#next-button").innerHTML = index === questions.length - 1
    ? "Finish quiz <span aria-hidden=\"true\">✓</span>"
    : "Next question <span aria-hidden=\"true\">→</span>";
}

function updateTimer() {
  $("#timer").textContent = `${String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:${String(secondsLeft % 60).padStart(2, "0")}`;
  $("#timer").classList.toggle("warning", secondsLeft <= 60);
}

function formatTime(seconds) {
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function finishQuiz(timeExpired = false) {
  if (finished) return;
  finished = true;
  clearInterval(timerId);
  const correct = questions.reduce((sum, item, i) => sum + (answers[i] === item.a ? 1 : 0), 0);
  const accuracy = Math.round(correct / questions.length * 100);
  const elapsed = Math.min(DURATION, Math.floor((Date.now() - startedAt) / 1000));
  $("#quiz-screen").hidden = true;
  $("#results-screen").hidden = false;
  $("#result-name").textContent = profile.name;
  $("#result-summary").textContent = timeExpired ? "Time ran out, so your current answers have been submitted." : "Your quiz is complete. Review your answers below.";
  $("#correct-score").textContent = `${correct}/${questions.length}`;
  $("#accuracy-score").textContent = `${accuracy}%`;
  $("#time-score").textContent = formatTime(timeExpired ? DURATION : elapsed);
  $("#score-message").textContent = accuracy >= 85
    ? "Excellent work. You answered most of these questions correctly."
    : accuracy >= 65
      ? "Nice work. You handled many of the questions correctly."
      : accuracy >= 40
        ? "You made a start. Read the explanations and try another round to practise."
        : "Good effort. Reviewing the explanations can help you practise these reasoning patterns.";
  renderReview();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function addReviewText(parent, label, value) {
  const p = document.createElement("p");
  const strong = document.createElement("strong");
  strong.textContent = label;
  p.append(strong, document.createTextNode(value));
  parent.append(p);
}

function renderReview() {
  const list = $("#review-list");
  list.replaceChildren();
  questions.forEach((item, i) => {
    const correct = answers[i] === item.a;
    const article = document.createElement("article");
    article.className = "review-item";
    const status = document.createElement("span");
    status.className = `review-status ${correct ? "correct" : "incorrect"}`;
    status.textContent = correct ? "Correct" : answers[i] === null ? "Not answered" : "Incorrect";
    const title = document.createElement("h3");
    title.textContent = `${i + 1}. ${item.q}`;
    article.append(status, title);
    addReviewText(article, "Your answer: ", answers[i] === null ? "No answer selected" : `${LETTERS[answers[i]]}. ${item.o[answers[i]]}`);
    addReviewText(article, "Correct answer: ", `${LETTERS[item.a]}. ${item.o[item.a]}`);
    addReviewText(article, "Explanation: ", item.e);
    list.append(article);
  });
}

function nextQuestion() {
  if (index < questions.length - 1) {
    index += 1;
    renderQuestion();
    return;
  }
  const unanswered = answers.filter((answer) => answer === null).length;
  if (unanswered && !window.confirm(`You have ${unanswered} unanswered question(s). Finish the quiz anyway?`)) return;
  finishQuiz();
}

function restartQuiz() {
  clearInterval(timerId);
  $("#profile-form").reset();
  $('input[name="interest"][value="technology"]').checked = true;
  $("#results-screen").hidden = true;
  $("#quiz-screen").hidden = true;
  $("#intro-screen").hidden = false;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

$("#profile-form").addEventListener("submit", startQuiz);
$("#previous-button").addEventListener("click", () => {
  if (index > 0) {
    index -= 1;
    renderQuestion();
  }
});
$("#next-button").addEventListener("click", nextQuestion);
$("#restart-button").addEventListener("click", restartQuiz);
