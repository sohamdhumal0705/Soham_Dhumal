MindMetrics Reasoning Quiz
==========================

Included files:
- index.html: page structure
- style.css: responsive styling
- script.js: question bank, quiz logic, timer, scoring, and answer review

Run locally:
1. Extract this ZIP.
2. Keep all three website files in the same folder.
3. Open index.html in a modern browser.

Deploy to GitHub Pages:
Upload index.html, style.css, and script.js into the root of your repository,
commit the changes, then set Settings > Pages to deploy from main / (root).

Note: This is an informal reasoning quiz. It does not measure a validated IQ score.
